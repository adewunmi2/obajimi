# -*- coding: utf-8 -*-
"""
Created on Tue Mar  8 08:16:49 2022

@author: Admin
"""

ones = []

for one in range(15):
    ones.append(1)
    
print(ones)

print(ones)

numbers = []

for number in range(15):
    numbers.append(7)
    
print(numbers)

num = []

for y in range(100, 150):
    num.append(y)
    
print(num)

even = []

for x in range(0, 100):
    if x % 2 == 0:
        even.append(x)
        
print(even)

years = []

for year in range(1950, 2020):
    if year % 4 == 0:
        years.append(year)
        
print(years)